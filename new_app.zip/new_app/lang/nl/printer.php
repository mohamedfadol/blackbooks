<?php

 return [
     'printers' => 'Printers',
     'add_printer' => 'Printer toevoegen',
     'name' => 'Printernaam',
     'connection_type' => 'Connectie type',
     'capability_profile' => 'Capability Profile',
     'ip_address' => 'IP adres',
     'port' => 'Haven',
     'path' => 'Pad',
     'added_success' => 'Printer succesvol toegevoegd',
     'manage_your_printers' => 'Beheer uw printers',
     'all_your_printer' => 'Alle geconfigureerde printers',
     'deleted_success' => 'Printer succesvol verwijderd',
     'edit_printer_setting' => 'Bewerk printerconfiguratie',
     'receipt_printers' => 'Ontvangstprinters',
     'character_per_line' => 'Personages per regel',
     'printer_name' => 'Printernaam',
     'updated_success' => 'Printer succesvol bijgewerkt',
     'edit_printer' => 'Bewerk printer',
 ];
