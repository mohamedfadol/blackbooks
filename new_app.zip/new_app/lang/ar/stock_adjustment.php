<?php

 return [
     'stock_adjustment' => 'المخزون التالف',
     'stock_adjustments' => 'المخزون التالف',
     'list' => 'قائمة المخزون التالف',
     'add' => 'اضافة مواد تالفة',
     'all_stock_adjustments' => 'جميع المخزون المواد التالفة',
     'search_product' => 'البحث عن المواد',
     'adjustment_type' => 'نوع الاتلاف',
     'normal' => 'عادي',
     'abnormal' => 'غير عادي',
     'total_amount' => 'الإجمالي',
     'total_amount_recovered' => 'الإجمالي المسترد',
     'reason_for_stock_adjustment' => 'السبب',
     'stock_adjustment_added_successfully' => 'تمت اضافة مخزون تالف بنجاح',
     'search_products' => 'البحث عن المواد',
     'delete_success' => 'تم حذف المخزون التالف بنجاح',
     'view_details' => 'عرض تفاصيل المخزون المواد التالفة ',
 ];
