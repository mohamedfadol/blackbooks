<?php

return [
    'name' => 'AssetManagement',
    'module_version' => '2.0',
    'pid' => 14,
];
