<?php

return [
    'name' => 'Connector',
    'module_version' => '2.0',
    'pid' => 9,
];
