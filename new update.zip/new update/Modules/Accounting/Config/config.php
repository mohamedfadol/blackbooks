<?php

return [
    'name' => 'Accounting',
    'module_version' => '0.7',
    'pid' => 16,
];
