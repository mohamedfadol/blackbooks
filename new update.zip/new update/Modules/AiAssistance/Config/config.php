<?php

return [
    'name' => 'AiAssistance',
    'module_version' => '1.1',
    'pid' => 17,
];
